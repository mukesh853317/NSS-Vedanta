import streamlit as st
from database import get_connection

def render_dashboard():
    st.markdown('<div class="main-title">NSS Dashboard</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Central overview of NSS activities and documentation</div>', unsafe_allow_html=True)

    conn = get_connection()
    total_activities = conn.execute("SELECT COUNT(*) FROM activities").fetchone()[0]
    total_volunteers = conn.execute("SELECT COUNT(*) FROM volunteers WHERE active=1").fetchone()[0]
    total_beneficiaries = conn.execute("SELECT COALESCE(SUM(beneficiaries),0) FROM activities").fetchone()[0]
    completed = conn.execute("SELECT COUNT(*) FROM activities WHERE status='Completed'").fetchone()[0]

    settings = conn.execute("SELECT * FROM settings WHERE id=1").fetchone()
    upcoming = conn.execute("""
        SELECT * FROM activities
        WHERE activity_date >= date('now')
        ORDER BY activity_date ASC LIMIT 8
    """).fetchall()
    recent = conn.execute("""
        SELECT * FROM activities
        ORDER BY activity_date DESC LIMIT 8
    """).fetchall()
    conn.close()

    st.info(f"**{settings['college_name']}** | {settings['nss_unit']} | Academic Year: **{settings['academic_year']}**")

    c1,c2,c3,c4 = st.columns(4)
    c1.metric("Activities", total_activities)
    c2.metric("Active Volunteers", total_volunteers)
    c3.metric("Beneficiaries", total_beneficiaries)
    c4.metric("Completed Activities", completed)

    st.subheader("Upcoming Activities")
    if upcoming:
        st.dataframe(
            [{"Date": r["activity_date"], "Activity": r["title"], "Type": r["activity_type"],
              "Venue": r["venue"] or "", "Status": r["status"]} for r in upcoming],
            use_container_width=True, hide_index=True
        )
    else:
        st.info("No upcoming activities. Add an activity from the Activities section.")

    st.subheader("Recent Activities")
    if recent:
        st.dataframe(
            [{"Code": r["activity_code"], "Date": r["activity_date"], "Activity": r["title"],
              "Beneficiaries": r["beneficiaries"], "Status": r["status"]} for r in recent],
            use_container_width=True, hide_index=True
        )
    else:
        st.info("No activities recorded yet.")
