import streamlit as st
from database import get_connection

def render_attendance():
    st.title("📝 Attendance")
    conn = get_connection()

    activities = conn.execute("SELECT id, activity_code, title, activity_date FROM activities ORDER BY activity_date DESC").fetchall()
    if not activities:
        st.info("Create an activity first.")
        conn.close()
        return

    activity_options = {f"{r['activity_code']} | {r['title']} | {r['activity_date']}": r["id"] for r in activities}
    selected_label = st.selectbox("Select Activity", list(activity_options.keys()))
    activity_id = activity_options[selected_label]

    volunteers = conn.execute("SELECT * FROM volunteers WHERE active=1 ORDER BY name").fetchall()
    if not volunteers:
        st.info("Add volunteers first.")
        conn.close()
        return

    st.subheader("Mark Attendance")
    existing = {
        r["volunteer_id"]: r for r in conn.execute(
            "SELECT * FROM attendance WHERE activity_id=?", (activity_id,)
        ).fetchall()
    }

    with st.form("attendance_form"):
        data = []
        header = st.columns([3,1,1])
        header[0].write("Volunteer")
        header[1].write("Present")
        header[2].write("Hours")

        for v in volunteers:
            cols = st.columns([3,1,1])
            cols[0].write(f"{v['enrollment_no']} - {v['name']}")
            old = existing.get(v["id"])
            present = cols[1].checkbox("Present", value=bool(old["present"]) if old else False, key=f"p_{v['id']}")
            hours = cols[2].number_input("Hours", min_value=0.0, max_value=24.0,
                                         value=float(old["hours"]) if old else 0.0,
                                         step=0.5, key=f"h_{v['id']}")
            data.append((v["id"], present, hours))

        save = st.form_submit_button("Save Attendance", type="primary")

    if save:
        for volunteer_id, present, hours in data:
            conn.execute("""INSERT INTO attendance(activity_id,volunteer_id,present,hours)
                VALUES(?,?,?,?)
                ON CONFLICT(activity_id,volunteer_id)
                DO UPDATE SET present=excluded.present, hours=excluded.hours""",
                (activity_id, volunteer_id, int(present), hours))
        conn.commit()
        st.success("Attendance saved.")

    conn.close()
