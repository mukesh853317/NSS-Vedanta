import streamlit as st
from pathlib import Path
from database import get_connection
from datetime import datetime

BASE = Path(__file__).resolve().parent.parent / "documents"
BASE.mkdir(exist_ok=True)

DOC_TYPES = [
    "Permission Letter", "Notice", "Activity Report", "Attendance",
    "Expense Statement", "Certificate", "Photo", "Newspaper Cutting", "Other"
]

def render_documents():
    st.title("📄 Documents & Evidence")
    conn = get_connection()
    activities = conn.execute("SELECT id, activity_code, title, activity_date FROM activities ORDER BY activity_date DESC").fetchall()

    if not activities:
        st.info("Create an activity first.")
        conn.close()
        return

    options = {f"{r['activity_code']} | {r['title']} | {r['activity_date']}": r["id"] for r in activities}
    label = st.selectbox("Activity", list(options.keys()))
    activity_id = options[label]

    st.subheader("Upload Document / Evidence")
    with st.form("upload"):
        doc_type = st.selectbox("Document Type", DOC_TYPES)
        uploaded = st.file_uploader("Choose file", type=["pdf","docx","doc","xlsx","xls","csv","jpg","jpeg","png","webp"])
        submit = st.form_submit_button("Upload", type="primary")

    if submit:
        if uploaded is None:
            st.error("Select a file.")
        else:
            activity = conn.execute("SELECT activity_code FROM activities WHERE id=?", (activity_id,)).fetchone()
            folder = BASE / activity["activity_code"]
            folder.mkdir(parents=True, exist_ok=True)
            safe_name = Path(uploaded.name).name
            stamp = datetime.now().strftime("%Y%m%d%H%M%S")
            target = folder / f"{stamp}_{safe_name}"
            target.write_bytes(uploaded.getbuffer())
            conn.execute("""INSERT INTO documents(activity_id,document_type,file_name,file_path)
                            VALUES(?,?,?,?)""",
                         (activity_id, doc_type, safe_name, str(target)))
            conn.commit()
            st.success("Document uploaded.")

    st.subheader("Existing Documents")
    docs = conn.execute("""SELECT * FROM documents WHERE activity_id=? ORDER BY uploaded_at DESC""", (activity_id,)).fetchall()
    if docs:
        for d in docs:
            st.write(f"**{d['document_type']}** — {d['file_name']}")
            try:
                with open(d["file_path"], "rb") as f:
                    st.download_button("Download", f.read(), file_name=d["file_name"], key=f"dl_{d['id']}")
            except FileNotFoundError:
                st.warning("Stored file is missing from the documents folder.")
    else:
        st.info("No documents uploaded for this activity.")

    conn.close()
