import streamlit as st
from database import get_connection
from datetime import date

def render_volunteers():
    st.title("👥 Volunteers")
    tab1, tab2 = st.tabs(["Volunteer List", "Add Volunteer"])
    conn = get_connection()

    with tab1:
        rows = conn.execute("SELECT * FROM volunteers ORDER BY name").fetchall()
        if rows:
            st.dataframe(
                [{"ID":r["id"], "Enrollment":r["enrollment_no"], "Name":r["name"],
                  "Class":r["class_name"] or "", "Division":r["division"] or "",
                  "Mobile":r["mobile"] or "", "Active":"Yes" if r["active"] else "No"} for r in rows],
                use_container_width=True, hide_index=True
            )
            q = st.text_input("Search volunteer")
            if q:
                found = conn.execute("""SELECT * FROM volunteers
                    WHERE name LIKE ? OR enrollment_no LIKE ?""", (f"%{q}%", f"%{q}%")).fetchall()
                st.dataframe(
                    [{"Enrollment":r["enrollment_no"], "Name":r["name"], "Class":r["class_name"] or "",
                      "Mobile":r["mobile"] or ""} for r in found],
                    use_container_width=True, hide_index=True
                )
        else:
            st.info("No volunteers added yet.")

    with tab2:
        with st.form("add_volunteer"):
            col1,col2 = st.columns(2)
            with col1:
                enrollment = st.text_input("Enrollment Number*")
                name = st.text_input("Full Name*")
                class_name = st.text_input("Class")
                division = st.text_input("Division")
            with col2:
                mobile = st.text_input("Mobile")
                email = st.text_input("Email")
                joining_date = st.date_input("Joining Date", date.today())
                active = st.checkbox("Active Volunteer", value=True)
            submit = st.form_submit_button("Add Volunteer", type="primary")

        if submit:
            if not enrollment.strip() or not name.strip():
                st.error("Enrollment Number and Name are required.")
            else:
                try:
                    conn.execute("""INSERT INTO volunteers
                    (enrollment_no,name,class_name,division,mobile,email,joining_date,active)
                    VALUES (?,?,?,?,?,?,?,?)""",
                    (enrollment.strip(),name.strip(),class_name,division,mobile,email,joining_date.isoformat(),int(active)))
                    conn.commit()
                    st.success("Volunteer added successfully.")
                except Exception as e:
                    st.error(f"Could not add volunteer: {e}")

    conn.close()
