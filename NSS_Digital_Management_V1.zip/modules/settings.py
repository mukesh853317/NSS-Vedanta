import streamlit as st
from database import get_connection

def render_settings():
    st.title("⚙️ Settings")
    conn = get_connection()
    s = conn.execute("SELECT * FROM settings WHERE id=1").fetchone()

    with st.form("settings"):
        college = st.text_input("College Name", s["college_name"])
        unit = st.text_input("NSS Unit", s["nss_unit"])
        officer = st.text_input("Programme Officer", s["programme_officer"])
        year = st.text_input("Academic Year", s["academic_year"])
        save = st.form_submit_button("Save Settings", type="primary")

    if save:
        conn.execute("""UPDATE settings SET college_name=?, nss_unit=?, programme_officer=?, academic_year=? WHERE id=1""",
                     (college, unit, officer, year))
        conn.commit()
        st.success("Settings saved.")
    conn.close()
