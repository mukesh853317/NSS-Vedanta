import streamlit as st
from database import get_connection
from datetime import date

ACTIVITY_TYPES = [
    "Cleanliness Drive", "Tree Plantation", "Blood Donation",
    "Health Check-up", "Road Safety", "Cyber Awareness",
    "Voter Awareness", "Environmental Awareness", "Swachhata Abhiyan",
    "National Day Programme", "NSS Foundation Day", "AIDS Awareness",
    "Disaster Management", "Literacy Programme", "Social Awareness",
    "Other"
]
STATUSES = ["Planned", "Ongoing", "Completed", "Cancelled"]

def render_activities():
    st.title("📅 Activities")
    tab1, tab2 = st.tabs(["Activity List", "Add Activity"])

    conn = get_connection()

    with tab1:
        rows = conn.execute("SELECT * FROM activities ORDER BY activity_date DESC").fetchall()
        if rows:
            st.dataframe(
                [{"ID":r["id"], "Code":r["activity_code"], "Date":r["activity_date"],
                  "Title":r["title"], "Type":r["activity_type"], "Venue":r["venue"] or "",
                  "Beneficiaries":r["beneficiaries"], "Status":r["status"]} for r in rows],
                use_container_width=True, hide_index=True
            )
            selected_id = st.number_input("Activity ID to view/edit", min_value=1, step=1)
            if st.button("Load Activity"):
                r = conn.execute("SELECT * FROM activities WHERE id=?", (selected_id,)).fetchone()
                if r:
                    st.session_state["edit_activity"] = dict(r)
                    st.rerun()
                else:
                    st.error("Activity not found.")

            if "edit_activity" in st.session_state:
                r = st.session_state["edit_activity"]
                st.subheader(f"Edit: {r['title']}")
                with st.form("edit_activity"):
                    title = st.text_input("Activity title", r["title"])
                    activity_type = st.selectbox("Activity type", ACTIVITY_TYPES, index=ACTIVITY_TYPES.index(r["activity_type"]) if r["activity_type"] in ACTIVITY_TYPES else len(ACTIVITY_TYPES)-1)
                    activity_date = st.date_input("Date", date.fromisoformat(r["activity_date"]))
                    venue = st.text_input("Venue", r["venue"] or "")
                    coordinator = st.text_input("Coordinator", r["coordinator"] or "")
                    beneficiaries = st.number_input("Beneficiaries", min_value=0, value=int(r["beneficiaries"] or 0))
                    status = st.selectbox("Status", STATUSES, index=STATUSES.index(r["status"]) if r["status"] in STATUSES else 0)
                    objectives = st.text_area("Objectives", r["objectives"] or "")
                    description = st.text_area("Description", r["description"] or "")
                    save = st.form_submit_button("Save Changes")
                if save:
                    conn.execute("""UPDATE activities SET title=?, activity_type=?, activity_date=?, venue=?,
                    coordinator=?, beneficiaries=?, status=?, objectives=?, description=? WHERE id=?""",
                    (title, activity_type, activity_date.isoformat(), venue, coordinator, beneficiaries,
                     status, objectives, description, r["id"]))
                    conn.commit()
                    st.success("Activity updated.")
                    del st.session_state["edit_activity"]
                    st.rerun()

                if st.button("Delete Activity", type="secondary"):
                    conn.execute("DELETE FROM activities WHERE id=?", (r["id"],))
                    conn.commit()
                    del st.session_state["edit_activity"]
                    st.success("Activity deleted.")
                    st.rerun()
        else:
            st.info("No activities available.")

    with tab2:
        with st.form("add_activity"):
            st.subheader("Create New NSS Activity")
            col1,col2 = st.columns(2)
            with col1:
                code = st.text_input("Activity Code*", placeholder="NSS-2026-001")
                title = st.text_input("Activity Title*")
                activity_type = st.selectbox("Activity Type", ACTIVITY_TYPES)
                activity_date = st.date_input("Activity Date", date.today())
                start_time = st.text_input("Start Time", placeholder="10:00")
                end_time = st.text_input("End Time", placeholder="13:00")
            with col2:
                venue = st.text_input("Venue")
                coordinator = st.text_input("Coordinator")
                beneficiaries = st.number_input("Expected/Actual Beneficiaries", min_value=0, value=0)
                status = st.selectbox("Status", STATUSES)
                academic_year = st.text_input("Academic Year", "2026-27")
            objectives = st.text_area("Objectives")
            description = st.text_area("Activity Description")
            submitted = st.form_submit_button("Create Activity", type="primary")

        if submitted:
            if not code.strip() or not title.strip():
                st.error("Activity Code and Activity Title are required.")
            else:
                try:
                    conn.execute("""INSERT INTO activities
                    (activity_code,title,activity_type,activity_date,start_time,end_time,venue,
                     objectives,description,coordinator,beneficiaries,status,academic_year)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (code.strip(),title.strip(),activity_type,activity_date.isoformat(),start_time,end_time,
                     venue,objectives,description,coordinator,beneficiaries,status,academic_year))
                    conn.commit()
                    st.success("Activity created successfully.")
                except Exception as e:
                    st.error(f"Could not create activity: {e}")

    conn.close()
